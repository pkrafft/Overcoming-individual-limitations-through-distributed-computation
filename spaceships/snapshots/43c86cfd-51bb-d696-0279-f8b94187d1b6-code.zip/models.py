from dallinger.nodes import Source
from dallinger.nodes import Agent
from dallinger.models import Info
from dallinger.models import Network

from sqlalchemy import Integer, String, Float
from sqlalchemy.ext.hybrid import hybrid_property
from sqlalchemy.sql.expression import cast

import random
import json

class WarOfTheGhostsSource(Source):
    """A Source that reads in a random story from a file and transmits it."""

    __mapper_args__ = {
        "polymorphic_identity": "war_of_the_ghosts_source"
    }

    def _contents(self):
        """Define the contents of new Infos.

        transmit() -> _what() -> create_information() -> _contents().
        """

        contents = {}

        n_turns = 20
        n_parts = 8

        good_prior = 0.5
        good_prob = 0.6
        bad_prob = 0.4

        part_probs = []
        for i in range(n_parts):
            if random.random() < good_prior:
                part_probs += [good_prob]
            else:
                part_probs += [bad_prob]

        fails = []
        for t in range(n_turns):
            fails += [[]]
            for i in range(n_parts):
                if random.random() < part_probs[i]:
                    fails[t] += ['success']
                else:
                    fails[t] += ['fail']

        contents['set'] = 1
        contents['turn'] = 0
        contents['part_probs'] = part_probs
        contents['fails'] = fails
        contents['action'] = ''

        contents = json.dumps(contents)

        return contents


class ParticleNetwork(Network):
    """A discrete generational network.

    A discrete generational network arranges agents into none-overlapping
    generations.

    generation_size dictates how many agents are in each generation,
    generations sets how many generations the network involves.

    Note that this network type assumes that agents have a property called
    generation. If you agents do not have this property it will not work.
    """

    __mapper_args__ = {"polymorphic_identity": "particle_network"}

    def __init__(self, generations, generation_size):
        """Endow the network with some persistent properties."""
        self.property1 = repr(generations)
        self.property2 = repr(generation_size)
        self.max_size = repr(generations * generation_size + 1)

    @property
    def generations(self):
        """The length of the network: the number of generations."""
        return int(self.property1)

    @property
    def generation_size(self):
        """The width of the network: the size of a single generation."""
        return int(self.property2)

    def add_node(self, node):
        """Link to the agent from a random parent"""

        nodes = [n for n in self.nodes() if not isinstance(n, Source) and n.id != node.id]

        if len(nodes) == 0:
            latest_gen = 0
            num_agents_in_latest = 0
        else:
            latest_gen = max([n.generation for n in nodes])
            num_agents_in_latest = sum([n.generation == latest_gen for n in nodes])

        if num_agents_in_latest == self.generation_size:
            curr_generation = latest_gen + 1
        else:
            curr_generation = latest_gen

        node.generation = curr_generation

        if curr_generation == 0:
            parent = self._select_oldest_source()
        else:
            parent = self._select_valid_node_from_generation(
                node_type=type(node),
                generation=curr_generation - 1)

        if parent is not None:

            parent.connect(whom=node)
            parent.transmit(to_whom=node)

            # if isinstance(parent, ShipSource):
            #     parent.transmit(to_whom=node)
            # else:
            #     parent.transmit(to_whom=node, what = Action)

    def _select_oldest_source(self):
        return self.nodes(type=Source)[0]

    def _select_valid_node_from_generation(self, node_type, generation):

        prev_agents = node_type.query\
            .filter_by(failed=False,
                       network_id=self.id,
                       generation=(generation))\
            .all()

        return random.choice(prev_agents)

class Particle(Agent):

    __mapper_args__ = {"polymorphic_identity": "particle"}

    def __init__(self, network, participant=None):
        super(Agent, self).__init__(network, participant)

    @hybrid_property
    def generation(self):
        """Convert property2 to genertion."""
        return int(self.property2)

    @generation.setter
    def generation(self, generation):
        """Make generation settable."""
        self.property2 = repr(generation)

    @generation.expression
    def generation(self):
        """Make generation queryable."""
        return cast(self.property2, Integer)
