from dallinger.nodes import Source
import random
import json

class WarOfTheGhostsSource(Source):
    """A Source that reads in a random story from a file and transmits it."""

    __mapper_args__ = {
        "polymorphic_identity": "war_of_the_ghosts_source"
    }

    def _contents(self):
        """Define the contents of new Infos.

        transmit() -> _what() -> create_information() -> _contents().
        """

        contents = {}

        n_turns = 20
        n_parts = 8

        good_prior = 0.5
        good_prob = 0.6
        bad_prob = 0.4

        part_probs = []
        for i in range(n_parts):
            if random.random() < good_prior:
                part_probs += [good_prob]
            else:
                part_probs += [bad_prob]

        fails = []
        for t in range(n_turns):
            fails += [[]]
            for i in range(n_parts):
                if random.random() < part_probs[i]:
                    fails[t] += ['success']
                else:
                    fails[t] += ['fail']

        contents['set'] = 1
        contents['turn'] = 0
        contents['part_probs'] = part_probs
        contents['fails'] = fails
        contents['action'] = ''

        contents = json.dumps(contents)

        return contents
