
var my_node_id;

var n_parts = 8;

var set;
var turn;
var fails;
var last_action;
var viewed_fails;

// Consent to the experiment.
$(document).ready(function() {

  // do not allow user to close or reload
  prevent_exit = true;

  // Print the consent form.
  $("#print-consent").click(function() {
    window.print();
  });

  // Consent to the experiment.
  $("#consent").click(function() {
    store.set("hit_id", getUrlParameter("hit_id"));
    store.set("worker_id", getUrlParameter("worker_id"));
    store.set("assignment_id", getUrlParameter("assignment_id"));
    store.set("mode", getUrlParameter("mode"));

    allow_exit();
    window.location.href = '/instructions';
  });

  // Consent to the experiment.
  $("#no-consent").click(function() {
    allow_exit();
    window.close();
  });

  // Consent to the experiment.
  $("#go-to-experiment").click(function() {
    allow_exit();
    window.location.href = '/exp';
  });

  $("#go-next").click(function() {
    $("#flow").hide();
    $("#response-form").show();
  });

  $("#submit-response").click(function() {

    $("#submit-response").addClass('disabled');
    $("#submit-response").html('Sending...');

    var response = {}
    response['set'] = set;
    response['fails'] = fails;
    response['turn'] = turn;
    response['action'] = read_action();
    response['viewed_fails'] = viewed_fails;
    response = JSON.stringify(response);

    reqwest({
      url: "/info/" + my_node_id,
      method: 'post',
      data: {
        contents: response,
        info_type: "Info"
      },
      success: function (resp) {
        create_agent();
      }
    });
  });

  // Submit the questionnaire.
  $("#submit-questionnaire").click(function() {
    submitResponses();
  });
});

// Create the agent.
var create_agent = function() {

  $("#flow").show();
  $("#response-form").hide();
  $("#go-next").addClass('disabled');
  $("#go-next").html('Loading...');

  reqwest({
    url: "/node/" + participant_id,
    method: 'post',
    type: 'json',
    success: function (resp) {
      my_node_id = resp.node.id;
      get_info(my_node_id);
    },
    error: function (err) {
      console.log(err);
      errorResponse = JSON.parse(err.response);
      if (errorResponse.hasOwnProperty('html')) {
        $('body').html(errorResponse.html);
      } else {
        allow_exit();
        go_to_page('questionnaire');
      }
    }
  });
};

var get_info = function() {
  reqwest({
    url: "/node/" + my_node_id + "/received_infos",
    method: 'get',
    type: 'json',
    success: function (resp) {

      var turn_info = JSON.parse(resp.infos[0].contents);

      set = turn_info.set;
      turn = parseInt(turn_info.turn) + 1;
      fails = turn_info.fails;
      last_action = turn_info.action;

      showTurn(false, turn, '', fails[turn - 2], last_action, set)

      $("#submit-response").removeClass('disabled');
      $("#submit-response").html('Submit');

      $("#go-next").removeClass('disabled');
      $("#go-next").html('Next');
    },
    error: function (err) {
      console.log(err);
      var errorResponse = JSON.parse(err.response);
      $('body').html(errorResponse.html);
    }
  });
};


function showTurn(single, this_turn, this_score, this_fails, this_last_action, this_set) {

  document.getElementById('turn').innerHTML = '<p><b>Round ' + this_turn + '</b>:</p>';
  document.getElementById('turn').innerHTML += '<p>You are playing round ' + this_turn + '.</p>'

  if(this_score != '') {
    document.getElementById('score').innerHTML = '<p>Current Score: ' + this_score + '</p>';
  }

  viewed_fails = new Array(n_parts+1).join('0').split('')

  var my_offset = '';
  if (this_turn > 1) {

    if(single) {
      document.getElementById('last-instr').innerHTML = "<p>Below, you can view the parts you used in your last design, if any, and which of those parts worked or failed on your last flight.</p><p>Any parts highlighted in red were faulty on the last ship's flight.</p>"
    } else {
      if(this_turn == 2) {
        document.getElementById('turn').innerHTML += '<p><i>1 player</i> before you has built a ship.</p>';
        document.getElementById('last-instr').innerHTML = "<p>Below, you can view the parts <i>the last player</i> used on their ship, if any, and which of those parts worked or failed on that player's flight.</p><p>Any parts highlighted in red were faulty on the last ship's flight.</p>";
      } else {
        document.getElementById('turn').innerHTML += '<p><i>' + (this_turn-1) + ' players</i> before you have built ships, each able to observe the design of the last player before them.</p>';
        document.getElementById('last-instr').innerHTML = "<p>Below, you can view the parts <i>the last player before you</i> used on their ship, if any, and which of those parts worked or failed on that player's flight.</p><p>Any parts highlighted in red were faulty on the last ship's flight.</p>";
      }
    }
    my_offset = 'left:305px;';
    if(single) {
      var parts = '<img src="/static/images/your-last-ship.png" style="width:300px;height:424px;position:absolute">';
    } else {
      var parts = '<img src="/static/images/last-ship.png" style="width:300px;height:424px;position:absolute">';
    }
    for (i = 0; i < n_parts; i++) {
      var failed = '';
      if(this_fails[i] == 'fail') {
        failed = '-failed';
      }
      if(this_last_action[i] == 1) {
        parts += '<img id="last-part-'+i+'" src="/static/images/set-' + this_set + '-part-' + (i + 1) + failed + '.png" style="width:300px;height:424px;position:absolute;visibility:visible">';
        if(failed) {
          viewed_fails[i] = 'fail'
        } else {
          viewed_fails[i] = 'success'
        }
      }
    }
    document.getElementById('last-parts').innerHTML = parts;
  } else {
    if(!single) {
      document.getElementById('turn').innerHTML += '<p><i>0 players</i> before you have built ships.</p>'
      document.getElementById('last-instr').innerHTML = "<p>You are the first to play.</p>";
    }
  }
  document.getElementById('your-ship').innerHTML = '<img src="/static/images/your-ship.png" style="width:300px;height:424px;position:absolute;'+my_offset+'">';

  var controls = '';
  for (i = 0; i < n_parts; i++) {
    controls += '<img id="icon-'+(i+1)+'" src="/static/images/set-' + this_set + '-part-' + (i+1) + '-icon.png" style="width:50px;height:50px;border:1px solid #021a40;" onclick="toggleViz('+i+')">';
  }
  document.getElementById('controls').innerHTML = controls;

  var parts = '';
  for (i = 0; i < n_parts; i++) {
    parts += '<img id="your-part-'+(i+1)+'" src="/static/images/set-' + this_set + '-part-' + (i+1) + '.png" style="width:300px;height:424px;position:absolute;'+my_offset+'visibility:hidden">';
  }
  document.getElementById('your-parts').innerHTML = parts;
}


function toggleViz(id) {
  var img = document.getElementById('your-part-' + (id+1));
  var ctrl = document.getElementById('icon-'+(id+1));
  var viz = img.style.visibility
  if(viz == 'hidden') {
    img.style.visibility = 'visible';
    ctrl.style.opacity = "0.25";
  } else {
    img.style.visibility = 'hidden';
    ctrl.style.opacity = "1.0";
  }
}

function read_action() {
  my_action = new Array(n_parts);
  for (i = 0; i < n_parts; i++) {
    var img = document.getElementById('your-part-' + (i+1));
    if(img.style.visibility == 'visible') {
      my_action[i] = 1
    } else {
      my_action[i] = 0
    }
  }
  return my_action;
};
