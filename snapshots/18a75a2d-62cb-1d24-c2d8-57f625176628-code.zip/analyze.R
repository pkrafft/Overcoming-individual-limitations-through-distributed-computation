
d = read.csv('evidence-pops.csv')
summary(lm(d[,'evidence'] ~ d[,'popularity']  + d[,'game']))
