
import pandas as pd
import numpy as np

import json

def parse_data(raw_data):
    """
    >>> df = pd.DataFrame({
    ... 'origin_id':[0,1,2,3],
    ... 'contents':[
    ... '{"turn":0,"set":1,"action":[],"fails":["fail","success","fail"]}',
    ... '{"turn":1,"set":1,"action":[0,1,1],"viewed_fails":["0","success","fail"]}',
    ... '{"turn":0,"set":2,"action":[],"fails":["fail","success","success"]}',
    ... '{"turn":1,"set":2,"action":[1,0,1],"viewed_fails":["0","success","success"]}',
    ... ]
    ... })
    >>> data,fails = parse_data(df)
    >>> data
          action  net  turn                 viewed
    0         []    1     0                     []
    1  [0, 1, 1]    1     1     [0, success, fail]
    2         []    2     0                     []
    3  [1, 0, 1]    2     1  [0, success, success]
    >>> fails
    {1: [u'fail', u'success', u'fail'], 2: [u'fail', u'success', u'success']}
    """

    nodes = sorted(list(set(raw_data['origin_id'])))

    turns = []
    nets = []
    actions = []
    viewed = []

    fails = {}

    for i in range(len(raw_data)):

        row = raw_data.iloc[i]
        contents = json.JSONDecoder().decode(row['contents'])

        turns += [contents['turn']]
        nets += [contents['set']]
        actions += [contents['action']]
        try:
            viewed += [contents['viewed_fails']]
        except:
            viewed += [[]]
            fails[contents['set']] = contents['fails']

    data = pd.DataFrame({'turn':turns,'net':nets,'action':actions,'viewed':viewed})

    return data,fails

def get_evidence(this_fails):
    """
    >>> this_fails = np.array([
    ... [['success','success','fail','fail'],['success','fail','fail','fail']],
    ... [['fail','fail','fail','fail'],['success','fail','fail','fail']],
    ... [['success','success','fail','fail'],['success','success','success','success']],
    ... ])
    >>> ne_ev = get_evidence(this_fails)
    >>> ne_ev[1]
    array([[ 0.5 ,  0.25],
           [ 0.  ,  0.25],
           [ 0.5 ,  1.  ]])
    >>> ne_ev[2]
    array([[ 0.5  ,  0.25 ],
           [ 0.25 ,  0.25 ],
           [ 0.25 ,  0.625]])
    >>> ne_ev[3]
    array([[ 0.5       ,  0.25      ],
           [ 0.25      ,  0.25      ],
           [ 0.33333333,  0.5       ]])
    """

    n_evidence = len(this_fails[0][0])
    
    evidence = np.sum(np.array(np.array(this_fails) == 'success', dtype=float),2)

    net_evidence = {}
    for i in range(1,len(this_fails)+1):
        net_evidence[i] = pd.rolling_sum(evidence, i, 1)
        norm = get_norm(evidence, n_evidence, i)
        net_evidence[i] /= np.array(norm, dtype = float)

    return net_evidence

def get_norm(evidence, n_evidence, window):
    """
    >>> evidence = np.array([[1,1],[1,1],[1,1]])
    >>> get_norm(evidence, 8, 1)
    array([[ 8.,  8.],
           [ 8.,  8.],
           [ 8.,  8.]])
    >>> get_norm(evidence, 8, 2)
    array([[  8.,   8.],
           [ 16.,  16.],
           [ 16.,  16.]])
    >>> get_norm(evidence, 8, 3)
    array([[  8.,   8.],
           [ 16.,  16.],
           [ 24.,  24.]])
    """
    
    n_parts = len(evidence[0])
    norm = np.ones((len(evidence),n_parts)) * window
    norm[:window] = np.transpose(np.array([range(window)]*n_parts) + 1)
    
    return norm * n_evidence

def get_pop(data, net, t):
    """
    >>> data = pd.DataFrame({
    ... 'net':[1,1,1,2],
    ... 'turn':[0,1,1,1],
    ... 'action':[[1,1],[0,1],[1,1],[1,1]],
    ... })
    >>> pop = get_pop(data,1,1)
    >>> data
       action  net  turn
    0  [1, 1]    1     0
    1  [0, 1]    1     1
    2  [1, 1]    1     1
    3  [1, 1]    2     1
    >>> pop
    array([ 0.5,  1. ])
    """

    turn_data = data.loc[(data['turn'] == t) & (data['net'] == net)]['action']
    mean_pop = np.mean(np.array([x for x in turn_data]), 0)

    return mean_pop

def get_reward(data, fails, net, t):
    """
    >>> 
    >>> data = pd.DataFrame({
    ... 'net':[1,1,1,2],
    ... 'turn':[2,2,2,2],
    ... 'action':[[1,1],[0,1],[1,1],[1,1]],
    ... })
    >>> fails = {1:np.array([
    ... [['success','success','fail','fail'],['success','fail','fail','fail']],
    ... [['fail','fail','fail','fail'],['success','fail','fail','fail']],
    ... [['success','success','fail','fail'],['success','success','success','success']],
    ... ])}
    >>> get_reward(data,fails,1,2)
    """

    mean_pop = get_pop(data, net, t)
    
    this_fails = fails[net]
    successes = np.sum(np.array(np.array(this_fails) == 'success', dtype=float),2)
    fails = np.sum(np.array(np.array(this_fails) == 'fail', dtype=float),2)
    totals = successes - fails    

    if t > 1:
        print(mean_pop, totals[t-2], totals[t-1])
    else:
        print(mean_pop, totals[t-1])
    
    return np.mean(mean_pop * totals[t-1])


if __name__ == "__main__":
    import doctest
    doctest.testmod()
