
import pandas as pd
import numpy as np

import json

in_dir = 'data-2018-01-16'

df = pd.read_csv('./data/' + in_dir + '/info.csv')

nodes = sorted(list(set(df['origin_id'])))

turns = []
nets = []
actions = []
viewed = []

fails = {}

for i in range(len(df)):

    row = df.iloc[i]
    contents = json.JSONDecoder().decode(row['contents'])

    turns += [contents['turn']]
    nets += [contents['set']]
    actions += [contents['action']]
    try:
        viewed += [contents['viewed_fails']]
    except:
        viewed += [[]]
        fails[contents['set']] = contents['fails']
    
data = pd.DataFrame({'turn':turns,'net':nets,'action':actions,'viewed':viewed})


for net in sorted(set(nets)):

    print('Net', net)
    evidence = np.array(np.array(fails[net]) == 'success', dtype=int)
    net_evidence =  pd.rolling_sum(evidence, len(fails[net]), 1)
    print(evidence[:(max(turns)-1)])
    print(net_evidence[:(max(turns)-1)])
    
    for t in sorted(set(turns)):

        if t > 0:
            turn_data = data.loc[(data['turn'] == t) & (data['net'] == net)]['action']
            mean_pop = np.mean(np.array([x for x in turn_data]), 0)
            print(mean_pop)

    print('Final correlation with last evidence', np.corrcoef(evidence[t-2],mean_pop)[0,1])
    print('Final correlation with total evidence', np.corrcoef(net_evidence[t-2],mean_pop)[0,1])
