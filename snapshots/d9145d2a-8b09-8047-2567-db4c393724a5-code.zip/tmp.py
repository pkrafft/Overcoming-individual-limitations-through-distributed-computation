
import matplotlib.pyplot as plt
import seaborn as sns

import numpy as np
import pandas as pd

import utils

import importlib
importlib.reload(utils)

#in_dir = '70f80fdf-rounds-10-evidence-1-population-5'
in_dir = 'abf00068-rounds-10-evidence-4-population-5'
#in_dir = 'd75786f7-data-2018-01-25-big-experiment'

n_evidence = 1

raw_data = pd.read_csv('./data/' + in_dir + '/info.csv')

data,fails,parts = utils.parse_data(raw_data)
